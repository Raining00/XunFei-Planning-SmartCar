var searchData=
[
  ['usingspaces',['UsingSpaces',['../class_c_simple_ini_templ.html#a9c967faf796cf5babea67e97975bed9b',1,'CSimpleIniTempl']]]
];
